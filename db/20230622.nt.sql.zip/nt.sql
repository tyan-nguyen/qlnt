-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 22, 2023 at 02:58 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nt`
--

-- --------------------------------------------------------

--
-- Table structure for table `nt_chi_phi`
--

DROP TABLE IF EXISTS `nt_chi_phi`;
CREATE TABLE IF NOT EXISTS `nt_chi_phi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_chi_phi` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `don_vi_tinh` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `don_gia` double NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `is_hidden` tinyint(1) DEFAULT NULL,
  `is_blocked` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nt_chi_phi`
--

INSERT INTO `nt_chi_phi` (`id`, `ten_chi_phi`, `don_vi_tinh`, `don_gia`, `ghi_chu`, `is_hidden`, `is_blocked`, `date_created`, `user_created`) VALUES
(1, 'Tiền phòng', 'Tháng', 0, '', 1, 1, '2023-06-16 10:36:51', 100),
(2, 'Tiền điện', 'KW', 5000, '', 0, 1, '2023-06-20 14:33:04', 100);

-- --------------------------------------------------------

--
-- Table structure for table `nt_day`
--

DROP TABLE IF EXISTS `nt_day`;
CREATE TABLE IF NOT EXISTS `nt_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_day` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nt_day`
--

INSERT INTO `nt_day` (`id`, `ten_day`, `ghi_chu`, `date_created`, `user_created`) VALUES
(3, 'Day 11', '', '2023-06-16 01:28:49', NULL),
(4, 'Day 2', 'zsfsf', '2023-06-16 01:29:14', 100),
(7, 'Tầng trệt', 'bao gồm 9 phòng', '2023-06-19 14:14:16', 100);

-- --------------------------------------------------------

--
-- Table structure for table `nt_hoa_don`
--

DROP TABLE IF EXISTS `nt_hoa_don`;
CREATE TABLE IF NOT EXISTS `nt_hoa_don` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phong` int(11) NOT NULL,
  `thang` int(11) NOT NULL,
  `nam` int(11) NOT NULL,
  `so_dien_truoc` float DEFAULT NULL,
  `so_dien_sau` float DEFAULT NULL,
  `so_nuoc_truoc` float DEFAULT NULL,
  `so_nuoc_sau` float DEFAULT NULL,
  `ngay_ghi_dien_nuoc` date DEFAULT NULL,
  `tong_tien` double DEFAULT NULL,
  `da_thanh_toan` tinyint(1) DEFAULT NULL,
  `ngay_thanh_toan` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_phong` (`id_phong`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nt_hoa_don`
--

INSERT INTO `nt_hoa_don` (`id`, `id_phong`, `thang`, `nam`, `so_dien_truoc`, `so_dien_sau`, `so_nuoc_truoc`, `so_nuoc_sau`, `ngay_ghi_dien_nuoc`, `tong_tien`, `da_thanh_toan`, `ngay_thanh_toan`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 1, 1, 2023, 100.5, 200, 10, 20, '2020-10-30', 100000.5, 1, '2020-10-30', 'sfdsfds', '2023-06-16 13:36:49', 100);

-- --------------------------------------------------------

--
-- Table structure for table `nt_hoa_don_chi_tiet`
--

DROP TABLE IF EXISTS `nt_hoa_don_chi_tiet`;
CREATE TABLE IF NOT EXISTS `nt_hoa_don_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hoa_don` int(11) NOT NULL,
  `id_chi_phi` int(11) NOT NULL,
  `so_luong` float DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `thanh_tien` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_hoa_don` (`id_hoa_don`),
  KEY `id_chi_phi` (`id_chi_phi`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nt_hoa_don_chi_tiet`
--

INSERT INTO `nt_hoa_don_chi_tiet` (`id`, `id_hoa_don`, `id_chi_phi`, `so_luong`, `don_gia`, `thanh_tien`, `ghi_chu`, `date_created`, `user_created`) VALUES
(2, 1, 1, 100.5, 50000.6999, 7000000, 'asdf', '2023-06-16 13:41:57', 100);

-- --------------------------------------------------------

--
-- Table structure for table `nt_nguoi_thue`
--

DROP TABLE IF EXISTS `nt_nguoi_thue`;
CREATE TABLE IF NOT EXISTS `nt_nguoi_thue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_phong` int(11) NOT NULL,
  `ho_ten` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ngay_sinh` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gioi_tinh` tinyint(1) DEFAULT NULL,
  `cccd` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trang_thai` tinyint(1) DEFAULT NULL,
  `ngay_bat_dau_thue` date DEFAULT NULL,
  `ngay_ngung_thue` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_phong` (`id_phong`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nt_nguoi_thue`
--

INSERT INTO `nt_nguoi_thue` (`id`, `id_phong`, `ho_ten`, `ngay_sinh`, `gioi_tinh`, `cccd`, `trang_thai`, `ngay_bat_dau_thue`, `ngay_ngung_thue`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 1, 'nguyen van a1', '20/10/1989', 1, 't3344777777777777777', 0, '2023-01-06', '2023-06-23', 'ghi chu', '2023-06-16 08:45:17', 100),
(2, 7, 'Nguyễn Văn A', '20/10/1989', 0, '', 1, '2023-06-01', '2023-06-29', '', '2023-06-16 08:55:58', 100),
(3, 2, 'ddd', '', 0, '', 1, NULL, NULL, '', '2023-06-21 15:50:37', 100),
(4, 1, 'sfsdf', '', 1, '', 1, NULL, NULL, '', '2023-06-21 15:51:46', 100),
(5, 2, 'fsadf', '', 0, '', 1, NULL, NULL, '', '2023-06-21 15:52:10', 100),
(6, 7, 'nguyen van a1', '', 0, '', 1, NULL, NULL, '', '2023-06-21 15:53:14', 100),
(7, 6, 'dfff', '1990', 1, '', 0, NULL, NULL, '', '2023-06-21 16:00:22', 100);

-- --------------------------------------------------------

--
-- Table structure for table `nt_phong`
--

DROP TABLE IF EXISTS `nt_phong`;
CREATE TABLE IF NOT EXISTS `nt_phong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_day` int(11) NOT NULL,
  `ten_phong` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `don_gia` double NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_day` (`id_day`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nt_phong`
--

INSERT INTO `nt_phong` (`id`, `id_day`, `ten_phong`, `don_gia`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 3, 'Phong 1', 1000000, 'ghi chu 1', '2023-06-16 08:33:55', 100),
(2, 4, 'Phong 2', 2000000.5, '', '2023-06-16 08:34:33', 100),
(6, 7, 'Phòng 1', 900000, '', '2023-06-20 09:35:14', 100),
(7, 3, 'Phòng 2', 1200000, 'ff', '2023-06-20 09:43:35', 100);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `nt_hoa_don`
--
ALTER TABLE `nt_hoa_don`
  ADD CONSTRAINT `nt_hoa_don_ibfk_1` FOREIGN KEY (`id_phong`) REFERENCES `nt_phong` (`id`);

--
-- Constraints for table `nt_hoa_don_chi_tiet`
--
ALTER TABLE `nt_hoa_don_chi_tiet`
  ADD CONSTRAINT `nt_hoa_don_chi_tiet_ibfk_1` FOREIGN KEY (`id_hoa_don`) REFERENCES `nt_hoa_don` (`id`),
  ADD CONSTRAINT `nt_hoa_don_chi_tiet_ibfk_2` FOREIGN KEY (`id_chi_phi`) REFERENCES `nt_chi_phi` (`id`);

--
-- Constraints for table `nt_nguoi_thue`
--
ALTER TABLE `nt_nguoi_thue`
  ADD CONSTRAINT `nt_nguoi_thue_ibfk_1` FOREIGN KEY (`id_phong`) REFERENCES `nt_phong` (`id`);

--
-- Constraints for table `nt_phong`
--
ALTER TABLE `nt_phong`
  ADD CONSTRAINT `nt_phong_ibfk_1` FOREIGN KEY (`id_day`) REFERENCES `nt_day` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
